require("dotenv").config();
import Cors from "@koa/cors";
import Koa, { Context } from "koa";
import Router from "koa-router";
import { koaBody } from "koa-body";
import { ironSession } from "iron-session/koa";
import rateLimit from "koa-ratelimit";

// TODO: APPLICATION
const App = new Koa({
  keys: ["for_jwt", "for_iron_session", "for_cipher"],
});

//
const Keys = App.keys as string[];

// TODO: DEFINE_ROUTER
export const R = new Router({
  strict: true,
  sensitive: true,
});

// TODO: REQUEST_RATE_LIMIT
App.use(
  rateLimit({
    driver: "memory",
    db: new Map(),
    duration: 60000,
    max: 10,
    headers: {
      remaining: "Rate-Limit-Remaining",
      reset: "Rate-Limit-Reset",
      total: "Rate-Limit-Total",
    },
    whitelist: (ctx) => {
      return ctx.path === "/login" || ctx.path === "/profile";
    },
    errorMessage: JSON.stringify({
      status: false,
      message: "You've reach the limit bro",
    }),
    id: (ctx: Context) => ctx.ip,
    throw: true,
  })
);

// TODO: SESSION_OPTIONS
App.use(
  ironSession({
    cookieName: "fanvercel/sess",
    password: "pcosjaucvthsauy8732g7qg6c7qwhcucsa",
    cookieOptions: {
      sameSite: "none",
      path: "/",
      secure: true,
      httpOnly: true,
      priority: "high",
    },
  })
);

// TODO: MANAGE_CORS
App.use(
  Cors({
    credentials: true,
  })
);

// TODO: ROUTER
App.use(koaBody());
App.use(R.routes());
App.use(R.allowedMethods());

// TODO: ERROR_HANDLING
App.on("error", (err, ctx: Context) => {
  ctx.response.status = 500;
  return (ctx.body = {
    status: JSON.parse(err?.message),
    route: ctx,
  });
});

// TODO: SERVER_PORT
App.listen(process.env.PORT, () => {
  console.log("Listening to : ", process.env.PORT);
});
