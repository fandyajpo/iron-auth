import { Context } from "koa";
import { R } from "./connection/IronKoa";
import withJwt from "jsonwebtoken";
import { sd } from "./lib/Function";
import { IronSession, IronSessionData, IronSessionOptions } from "iron-session";

// TODO: CREATE_TOKEN
const createToken = (config: object): string | null => {
  try {
    const accessToken = withJwt.sign(config, "nqwucabjhacjsanj", {
      expiresIn: "10m",
    });
    return accessToken;
  } catch (err) {
    return null;
  }
};

const refresh = async (token: string) => {
  let condition;
  try {
    const jResult = withJwt.verify(token, "nqwucabjhacjsanj");

    return (condition = {
      status: "ok",
      message: "Fresh",
    });
  } catch (error) {
    return (condition = {
      status: "expired",
      message: "Refresh token has expired",
    });
  }
};

// TODO: MIDDLEWARE
const middleware = () => null;

// TODO: TOKEN_VALIDATOR
const verify = async (token: string): Promise<object> => {
  let condition: object;
  try {
    const jResult = withJwt.verify(token, "nqwucabjhacjsanj");

    return (condition = {
      status: "ok",
      message: `Fresh until ${jResult}`,
    });
  } catch (error) {
    return (condition = {
      status: "expired",
      message: "Access token has expired",
    });
  }
};

// TODO: MAIN_APP
const main = () => {
  // TODO: LOGIN ROUTE
  R.post("/login", async (ctx: Context): Promise<object | void> => {
    try {
      const { user, pass } = ctx.request.body;
      console.log(user, pass);

      const username = sd(user);
      const password = sd(pass);

      if (username !== "fandy") {
        ctx.response.status = 400;
        return (ctx.body = { message: "invalid user", status: false });
      }

      if (password !== "fandy") {
        ctx.response.status = 400;
        return (ctx.body = { message: "invalid pass", status: false });
      }

      const token = await createToken({
        username,
        password,
      });

      ctx.session.user = { token };
      await ctx.session.save();
      ctx.body = { message: "login success" };
    } catch (error) {
      ctx.response.status = 400;
      return (ctx.body = { message: "login failure", status: false });
    }
  });
  // TODO: LOGOUT_ROUTE
  R.post("/logout", async (ctx: Context): Promise<object | void> => {
    try {
      if (ctx.session.user) {
        ctx.session.destroy();
        ctx.body = { message: "logout" };
      } else {
        ctx.throw(500, { message: "restricted" });
      }
    } catch (error) {
      ctx.response.status = 500;
      return (ctx.body = { message: "is not login", status: false });
    }
  });
  // TODO: CHECK_DETAIL_BY_SESSION
  R.get("/profile", async (ctx: Context): Promise<object | void> => {
    try {
      if (ctx.session.user) {
        ctx.body = { user: ctx.session.user };
      } else {
        ctx.throw(500, { message: "restricted" });
      }
    } catch (error) {
      ctx.response.status = 500;
      return (ctx.body = { message: "is not login", status: false });
    }
  });
  // TODO: TOKEN_VALIDATION
  R.post("/checker", async (ctx: Context): Promise<object | void> => {
    try {
      const { token } = ctx.session.user;
      const tokenCheck = await verify(token);

      if (ctx.session.user) {
        ctx.body = { token, status: tokenCheck };
      } else {
        ctx.throw(500, { message: "restricted" });
      }
    } catch (error) {
      ctx.response.status = 500;
      return (ctx.body = { message: "is not login", status: false });
    }
  });
  // TODO: TEST_ROUTE
  R.get("/test", async (ctx: Context): Promise<object | void> => {
    try {
      ctx.body = { message: "Test APi" };
    } catch (error) {
      ctx.response.status = 500;
      return (ctx.body = { status: false });
    }
  });
  // TODO: REFRESH_TOKEN
  // R.get("/refresh", async (ctx: Context): Promise<object | void> => {
  //   let detail, newAuth;
  //   try {
  //     const { refreshToken } = ctx.request.body;
  //     if (!refreshToken) {
  //       ctx.response.status = 400;
  //       return (ctx.body = { message: "Forbidden" });
  //     }
  //     const rverify = await refresh(refreshToken);
  //     const data = await dec(refreshToken);
  //     delete data?.iat;
  //     delete data?.exp;

  //     if (rverify.status === "ok") {
  //       detail = data;
  //       const regenerate = await CreateTokens(detail);
  //       newAuth = regenerate;
  //     }
  //     ctx.response.status = 200;
  //     return (ctx.body = newAuth);
  //   } catch (error) {
  //     ctx.response.status = 400;
  //     return (ctx.body = { status: ctx.status, message: e.message });
  //   }
  // });
};

main();
