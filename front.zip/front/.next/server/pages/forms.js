"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/forms";
exports.ids = ["pages/forms"];
exports.modules = {

/***/ "./pages/forms.tsx":
/*!*************************!*\
  !*** ./pages/forms.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n// import { FormEventHandler, FormEvent } from \"react\";\n// export default function Home() {\n//   const submit: FormEventHandler<HTMLFormElement> = async (\n//     e: FormEvent<HTMLFormElement>\n//   ) => {\n//     e.preventDefault();\n//     console.log(\"Barang 1 : \", e?.currentTarget?.barang_1?.value);\n//   };\n//   return (\n//     <div className=\"bg-red-500 w-full h-screen \">\n//       <form\n//         onSubmit={submit}\n//         className=\"p-4 rounded-xl flex flex-col items-center gap-2 w-auto\"\n//       >\n//         <input\n//           name=\"barang_1\"\n//           className=\"border rounded-xl p-2\"\n//           placeholder=\"Name\"\n//           type=\"text\"\n//           autoComplete=\"off\"\n//         />\n//         <input type={\"submit\"} className=\"border text-white rounded-xl p-2\" />\n//       </form>\n//     </div>\n//   );\n// }\n\n\nfunction Home() {\n    const [v, setV] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const submit = async ()=>{\n        console.log(\"Barang 1 : \", v);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"bg-red-500 w-full h-screen \",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                onChange: (e)=>setV(e.target.value),\n                name: \"barang_1\",\n                className: \"border rounded-xl p-2\",\n                placeholder: \"Name\",\n                type: \"text\",\n                autoComplete: \"off\"\n            }, void 0, false, {\n                fileName: \"/home/fanvercel/Documents/AuthTest/front/pages/forms.tsx\",\n                lineNumber: 40,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                type: \"button\",\n                onClick: submit,\n                className: \"border text-white rounded-xl p-2\",\n                children: \"Submit\"\n            }, void 0, false, {\n                fileName: \"/home/fanvercel/Documents/AuthTest/front/pages/forms.tsx\",\n                lineNumber: 49,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/home/fanvercel/Documents/AuthTest/front/pages/forms.tsx\",\n        lineNumber: 39,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9mb3Jtcy50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSx1REFBdUQ7QUFFdkQsbUNBQW1DO0FBQ25DLDhEQUE4RDtBQUM5RCxvQ0FBb0M7QUFDcEMsV0FBVztBQUNYLDBCQUEwQjtBQUMxQixxRUFBcUU7QUFDckUsT0FBTztBQUVQLGFBQWE7QUFDYixvREFBb0Q7QUFDcEQsY0FBYztBQUNkLDRCQUE0QjtBQUM1Qiw2RUFBNkU7QUFDN0UsVUFBVTtBQUNWLGlCQUFpQjtBQUNqQiw0QkFBNEI7QUFDNUIsOENBQThDO0FBQzlDLCtCQUErQjtBQUMvQix3QkFBd0I7QUFDeEIsK0JBQStCO0FBQy9CLGFBQWE7QUFFYixpRkFBaUY7QUFDakYsZ0JBQWdCO0FBQ2hCLGFBQWE7QUFDYixPQUFPO0FBQ1AsSUFBSTs7QUFFNkI7QUFDbEIsU0FBU0MsT0FBTztJQUM3QixNQUFNLENBQUNDLEdBQUdDLEtBQUssR0FBR0gsK0NBQVFBLENBQUM7SUFDM0IsTUFBTUksU0FBUyxVQUFZO1FBQ3pCQyxRQUFRQyxHQUFHLENBQUMsZUFBZUo7SUFDN0I7SUFFQSxxQkFDRSw4REFBQ0s7UUFBSUMsV0FBVTs7MEJBQ2IsOERBQUNDO2dCQUNDQyxVQUFVLENBQUNDLElBQU1SLEtBQUtRLEVBQUVDLE1BQU0sQ0FBQ0MsS0FBSztnQkFDcENDLE1BQUs7Z0JBQ0xOLFdBQVU7Z0JBQ1ZPLGFBQVk7Z0JBQ1pDLE1BQUs7Z0JBQ0xDLGNBQWE7Ozs7OzswQkFHZiw4REFBQ0M7Z0JBQ0NGLE1BQU07Z0JBQ05HLFNBQVNmO2dCQUNUSSxXQUFVOzBCQUNYOzs7Ozs7Ozs7Ozs7QUFLUCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJvbnQvLi9wYWdlcy9mb3Jtcy50c3g/ZTJhOSJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpbXBvcnQgeyBGb3JtRXZlbnRIYW5kbGVyLCBGb3JtRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcblxuLy8gZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbi8vICAgY29uc3Qgc3VibWl0OiBGb3JtRXZlbnRIYW5kbGVyPEhUTUxGb3JtRWxlbWVudD4gPSBhc3luYyAoXG4vLyAgICAgZTogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD5cbi8vICAgKSA9PiB7XG4vLyAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuLy8gICAgIGNvbnNvbGUubG9nKFwiQmFyYW5nIDEgOiBcIiwgZT8uY3VycmVudFRhcmdldD8uYmFyYW5nXzE/LnZhbHVlKTtcbi8vICAgfTtcblxuLy8gICByZXR1cm4gKFxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTUwMCB3LWZ1bGwgaC1zY3JlZW4gXCI+XG4vLyAgICAgICA8Zm9ybVxuLy8gICAgICAgICBvblN1Ym1pdD17c3VibWl0fVxuLy8gICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMiB3LWF1dG9cIlxuLy8gICAgICAgPlxuLy8gICAgICAgICA8aW5wdXRcbi8vICAgICAgICAgICBuYW1lPVwiYmFyYW5nXzFcIlxuLy8gICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkLXhsIHAtMlwiXG4vLyAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOYW1lXCJcbi8vICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4vLyAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbi8vICAgICAgICAgLz5cblxuLy8gICAgICAgICA8aW5wdXQgdHlwZT17XCJzdWJtaXRcIn0gY2xhc3NOYW1lPVwiYm9yZGVyIHRleHQtd2hpdGUgcm91bmRlZC14bCBwLTJcIiAvPlxuLy8gICAgICAgPC9mb3JtPlxuLy8gICAgIDwvZGl2PlxuLy8gICApO1xuLy8gfVxuXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW3YsIHNldFZdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IHN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zb2xlLmxvZyhcIkJhcmFuZyAxIDogXCIsIHYpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtNTAwIHctZnVsbCBoLXNjcmVlbiBcIj5cbiAgICAgIDxpbnB1dFxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFYoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICBuYW1lPVwiYmFyYW5nXzFcIlxuICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZC14bCBwLTJcIlxuICAgICAgICBwbGFjZWhvbGRlcj1cIk5hbWVcIlxuICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAvPlxuXG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9e1wiYnV0dG9uXCJ9XG4gICAgICAgIG9uQ2xpY2s9e3N1Ym1pdH1cbiAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHRleHQtd2hpdGUgcm91bmRlZC14bCBwLTJcIlxuICAgICAgPlxuICAgICAgICBTdWJtaXRcbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm5hbWVzIjpbInVzZVN0YXRlIiwiSG9tZSIsInYiLCJzZXRWIiwic3VibWl0IiwiY29uc29sZSIsImxvZyIsImRpdiIsImNsYXNzTmFtZSIsImlucHV0Iiwib25DaGFuZ2UiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJuYW1lIiwicGxhY2Vob2xkZXIiLCJ0eXBlIiwiYXV0b0NvbXBsZXRlIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/forms.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/forms.tsx"));
module.exports = __webpack_exports__;

})();