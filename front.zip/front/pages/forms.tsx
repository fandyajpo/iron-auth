// import { FormEventHandler, FormEvent } from "react";

// export default function Home() {
//   const submit: FormEventHandler<HTMLFormElement> = async (
//     e: FormEvent<HTMLFormElement>
//   ) => {
//     e.preventDefault();
//     console.log("Barang 1 : ", e?.currentTarget?.barang_1?.value);
//   };

//   return (
//     <div className="bg-red-500 w-full h-screen ">
//       <form
//         onSubmit={submit}
//         className="p-4 rounded-xl flex flex-col items-center gap-2 w-auto"
//       >
//         <input
//           name="barang_1"
//           className="border rounded-xl p-2"
//           placeholder="Name"
//           type="text"
//           autoComplete="off"
//         />

//         <input type={"submit"} className="border text-white rounded-xl p-2" />
//       </form>
//     </div>
//   );
// }

import { useState } from "react";
export default function Home() {
  const [v, setV] = useState("");
  const submit = async () => {
    console.log("Barang 1 : ", v);
  };

  return (
    <div className="bg-red-500 w-full h-screen ">
      <input
        onChange={(e) => setV(e.target.value)}
        name="barang_1"
        className="border rounded-xl p-2"
        placeholder="Name"
        type="text"
        autoComplete="off"
      />

      <button
        type={"button"}
        onClick={submit}
        className="border text-white rounded-xl p-2"
      >
        Submit
      </button>
    </div>
  );
}
