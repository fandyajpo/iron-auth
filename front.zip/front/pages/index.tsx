import { GetServerSidePropsContext } from "next";
import { withIronSessionSsr } from "iron-session/next";
import axios, { AxiosError } from "axios";
import { FormEventHandler, FormEvent } from "react";
import { SavedSession, sessionOptions } from "@/lib/Session";
import { useRouter } from "next/router";
import { sc } from "@/lib/Function";
export default function Home(props: any) {
  const router = useRouter();
  const login: FormEventHandler<HTMLFormElement> = async (
    e: FormEvent<HTMLFormElement>
  ) => {
    e.preventDefault();
    try {
      const poster = await axios("http://localhost:5000/login", {
        withCredentials: true,
        method: "POST",
        data: {
          user: sc(e.currentTarget?.user?.value),
          pass: sc(e.currentTarget?.pass?.value),
        },
        headers: {
          "Content-Type": "application/json",
        },
      });
      const result = await poster.data;
      console.log(result);
      router.replace("/");
    } catch (error) {
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError<Error>;
        if (axiosError.response?.data.message) {
          alert(axiosError.response?.data.message);
        }
      } else {
        console.log(error);
      }
    }
  };

  const profile = async () => {
    try {
      const poster = await axios("http://localhost:5000/profile", {
        withCredentials: true,
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const result = await poster.data;
      console.log(result);
    } catch (error) {
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        console.log(axiosError.response?.data);
      } else {
        console.log(error);
      }
    }
  };

  const checker = async () => {
    try {
      const poster = await axios("http://localhost:5000/checker", {
        withCredentials: true,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const result = await poster.data;
      console.log(result);
    } catch (error) {
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        console.log(axiosError.response?.data);
      } else {
        console.log(error);
      }
    }
  };

  const logout = async () => {
    try {
      const poster = await axios("/api/logout", {
        withCredentials: true,
        method: "GET",
      });
      const result = await poster.data;
      console.log(result);

      router.replace("/");
    } catch (error) {
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        console.log(axiosError.response?.data);
      } else {
        console.log(error);
      }
    }
  };

  return (
    <div className="bg-black w-full h-screen p-8 space-y-2">
      <div className="flex flex-row gap-2">
        <button
          className="bg-blue-500 text-white p-2 rounded-xl"
          onClick={profile}
        >
          Profile
        </button>
        <button
          className="bg-red-500 text-white p-2 rounded-xl"
          onClick={logout}
        >
          Logout
        </button>
        <button
          className="bg-yellow-500 text-white p-2 rounded-xl"
          onClick={checker}
        >
          Checker
        </button>
      </div>
      <form
        onSubmit={login}
        className="bg-green-500 p-4 rounded-xl flex flex-row items-center gap-2"
      >
        <input
          name="user"
          className="border rounded-xl p-2"
          placeholder="username"
        />
        <input
          name="pass"
          className="border rounded-xl p-2"
          placeholder="password"
        />
        <input type={"submit"} className="border text-white rounded-xl p-2" />
      </form>
      <pre className="text-white">{JSON.stringify(props, null, 2)}</pre>
    </div>
  );
}

export const getServerSideProps = withIronSessionSsr(
  async (context: GetServerSidePropsContext) => {
    const user: SavedSession = context.req.session.user;

    // @ts-ignored
    if (user?.token) {
      return {
        props: {
          isLogin: true,
        },
      };
    }

    return {
      props: {
        isLogin: false,
      },
    };
  },
  sessionOptions
);
