import type { NextApiRequest, NextApiResponse } from "next";
import { withIronSessionApiRoute } from "iron-session/next";
import { sessionOptions } from "lib/Session";

export default withIronSessionApiRoute(
  async (req: NextApiRequest, res: NextApiResponse) => {
    const user = await req.session.destroy();

    return res.status(200).json({
      user,
      logout: true,
    });
  },
  sessionOptions
);
