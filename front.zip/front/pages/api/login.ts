import type { NextApiRequest, NextApiResponse } from "next";
import FetchJson from "@/lib/Fetch";
export default async function Handle(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    const poster = await FetchJson({
      credentials: "include",
      url: "login",
      body: {
        pass: req?.body?.pass,
        user: req?.body?.user,
      },
      headers: {
        "Content-Type": "application/json",
      },
      method: "POST",
    });
    // console.log(req.cookies);
    return res.status(200).json(poster);
  } catch (error) {
    return res.status(500).json(error);
  }
}
