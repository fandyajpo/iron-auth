import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { createContext, useState } from "react";

export const GlobalContext = createContext({});

const GlobalProvider = ({
  children,
}: {
  children: JSX.Element | JSX.Element[];
}) => {
  const [nama, setNama] = useState("siapa");

  const value = {
    nama,
    setNama,
  };

  return (
    <GlobalContext.Provider value={{ value }}>
      {children}
    </GlobalContext.Provider>
  );
};

export default function App({ Component, pageProps }: AppProps) {
  return (
    <GlobalProvider>
      <Component {...pageProps} />
    </GlobalProvider>
  );
}
