interface FetchOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: any;
  headers?: any;
  signal?: any;
  url?: string | any;
  credentials?: "include" | "same-origin" | "omit";
}

export default async function FetchJson(Init: FetchOptions) {
  const response = await fetch(
    (process.env.KOA_SERVICE_URL as string) + Init.url,
    {
      method: Init.method,
      headers: Init.headers,
      body: JSON.stringify(Init.body),
      credentials: Init.credentials,
      mode: "no-cors",
    }
  );

  const data = await response.json();
  if (response.ok) return data;
  throw new FetchError({
    message: response.statusText,
    response,
    data,
  });
}

export class FetchError extends Error {
  response;
  data;
  constructor({ message, response, data }: string | any) {
    super(message);
    this.name = "FetchError";
    this.response = response;
    this.data = data ?? { message: message };
    if (Error) {
      Error(this.message);
    }
  }
}
